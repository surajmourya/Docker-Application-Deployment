import Styled from 'styled-components';

export const SpanStyled = Styled.span`
  font-weight: bold;
`;
