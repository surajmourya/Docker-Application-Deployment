export interface SpanProps {
  value?: string;
}
