export interface ButtonProps {
  value?: string;
  handleOnClick: () => void;
}
