export interface TileProps {
  value: string;
  handleOnClick: () => void;
}
