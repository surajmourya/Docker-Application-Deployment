import Styled from 'styled-components';

export const TitleStyled = Styled.h1`
  text-align: center;
`;
