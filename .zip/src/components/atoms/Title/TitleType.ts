export interface TitleProps {
  value?: string;
}
