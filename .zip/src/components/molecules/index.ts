import { DarkModeSwitch } from './DarkModeSwitch/DarkModeSwitch';

export {
  DarkModeSwitch
};
