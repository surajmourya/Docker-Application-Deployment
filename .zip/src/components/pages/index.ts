import { HomePage } from './HomePage/HomePage';

export {
  HomePage
};
