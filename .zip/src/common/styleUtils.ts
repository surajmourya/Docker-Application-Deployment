export const blackColor = '#222';
export const whiteColor = '#ddd';

export const space30 = '30px';
export const space60 = '60px';
export const space120 = '120px';

export const tileSize = 64;
